import { Router } from 'express';
import { resetDatabase } from '../db/database.js';
import { cache } from '../cache.js';

const router = Router();

// GET /api/health - Backend & database health check
router.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
    database: 'SQLite (native node:sqlite WAL mode)',
    cache: cache.stats()
  });
});

// POST /api/reset - Reset SQLite state to seed data and flush cache
router.post('/reset', (req, res, next) => {
  try {
    resetDatabase();
    cache.delByPrefix('rec:'); // invalidate stale recommendation cache
    res.json({
      success: true,
      message: 'SQLite database restored to initial seed state (4.4 stars across 18 reviews for The Midnight Library).'
    });
  } catch (err) {
    next(err);
  }
});

export default router;
