/**
 * Lightweight in-process TTL cache with LRU eviction.
 *
 * Acts as a Redis-compatible interface layer: the same `get` / `set` / `del`
 * API means swapping to a real Redis client (ioredis) later requires changing
 * only this file.
 *
 * Usage:
 *   import { cache } from './cache.js';
 *   const hit = cache.get('rec:Fiction:reflective');
 *   if (!hit) { cache.set('rec:Fiction:reflective', result, 60); }
 */

const DEFAULT_TTL_SECONDS = 60;
const MAX_ENTRIES = 256;

class TtlCache {
  constructor(maxEntries = MAX_ENTRIES) {
    /** @type {Map<string, { value: any, expiresAt: number }>} */
    this._store = new Map();
    this._maxEntries = maxEntries;
    this.hits = 0;
    this.misses = 0;
  }

  /**
   * Retrieve a cached value. Returns null on miss or expiry.
   * @param {string} key
   * @returns {any|null}
   */
  get(key) {
    const entry = this._store.get(key);
    if (!entry) { this.misses++; return null; }
    if (Date.now() > entry.expiresAt) {
      this._store.delete(key);
      this.misses++;
      return null;
    }
    // LRU: move to end by re-inserting
    this._store.delete(key);
    this._store.set(key, entry);
    this.hits++;
    return entry.value;
  }

  /**
   * Store a value with a TTL.
   * @param {string} key
   * @param {any}    value
   * @param {number} [ttlSeconds]
   */
  set(key, value, ttlSeconds = DEFAULT_TTL_SECONDS) {
    // Evict oldest entry when at capacity
    if (this._store.size >= this._maxEntries && !this._store.has(key)) {
      const oldest = this._store.keys().next().value;
      this._store.delete(oldest);
    }
    this._store.set(key, { value, expiresAt: Date.now() + ttlSeconds * 1000 });
  }

  /**
   * Invalidate a single key.
   * @param {string} key
   */
  del(key) {
    this._store.delete(key);
  }

  /**
   * Invalidate all keys matching a prefix.
   * @param {string} prefix
   */
  delByPrefix(prefix) {
    for (const key of this._store.keys()) {
      if (key.startsWith(prefix)) this._store.delete(key);
    }
  }

  /** Current live entry count (excludes expired entries not yet evicted). */
  get size() { return this._store.size; }

  /** Cache efficiency ratio (0–1). Returns null when no lookups yet. */
  get hitRate() {
    const total = this.hits + this.misses;
    return total === 0 ? null : this.hits / total;
  }

  /** Diagnostic snapshot for the /api/health endpoint. */
  stats() {
    return {
      size: this.size,
      hits: this.hits,
      misses: this.misses,
      hitRate: this.hitRate !== null ? `${(this.hitRate * 100).toFixed(1)}%` : 'n/a'
    };
  }
}

// Singleton shared across the process
export const cache = new TtlCache();
