/**
 * Structured logger using pino (zero-dep, JSON output for production, pretty for dev)
 * Usage: import { logger } from './logger.js'
 *        logger.info({ bookId }, 'Review submitted')
 *        logger.warn({ err }, 'DB lock contention')
 *        logger.error({ err }, 'Unhandled exception')
 */

// Use pino when available; fall back to a lightweight console shim so the app
// always starts even if the optional dep was not installed.
let pinoInstance = null;
try {
  const { default: pino } = await import('pino');
  pinoInstance = pino({
    level: process.env.LOG_LEVEL || (process.env.NODE_ENV === 'production' ? 'info' : 'debug'),
    transport:
      process.env.NODE_ENV !== 'production'
        ? { target: 'pino-pretty', options: { colorize: true, translateTime: 'SYS:standard' } }
        : undefined
  });
} catch {
  // pino not installed — use structured console shim
  const fmt = (level, obj, msg) => {
    const { err, ...rest } = obj || {};
    const base = { level, time: new Date().toISOString(), msg, ...rest };
    if (err) base.err = { message: err.message, code: err.code, stack: err.stack };
    console[level === 'error' ? 'error' : level === 'warn' ? 'warn' : 'log'](JSON.stringify(base));
  };
  pinoInstance = {
    debug: (obj, msg) => fmt('debug', obj, msg),
    info:  (obj, msg) => fmt('info',  obj, msg),
    warn:  (obj, msg) => fmt('warn',  obj, msg),
    error: (obj, msg) => fmt('error', obj, msg),
    child: () => pinoInstance
  };
}

export const logger = pinoInstance;
