import { Router } from 'express';
import { BooksDao, ReviewsDao } from '../db/database.js';

const router = Router();

/**
 * @openapi
 * /api/books:
 *   get:
 *     summary: List the book catalogue
 *     parameters:
 *       - in: query
 *         name: genre
 *         schema: { type: string }
 *         description: Filter by genre label (e.g. Fiction, Sci-Fi)
 *       - in: query
 *         name: search
 *         schema: { type: string }
 *         description: Full-text search across title, author and synopsis
 *       - in: query
 *         name: page
 *         schema: { type: integer, default: 1 }
 *       - in: query
 *         name: limit
 *         schema: { type: integer, default: 16, maximum: 100 }
 *     responses:
 *       200:
 *         description: Paginated book list
 */
router.get('/', (req, res, next) => {
  try {
    const { genre, search, page, limit } = req.query;
    const result = BooksDao.getAll(genre, search, page, limit);
    res.json({ success: true, count: result.total, ...result });
  } catch (err) {
    next(err);
  }
});

/**
 * @openapi
 * /api/books/{id}:
 *   get:
 *     summary: Get a single book by ID
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200:
 *         description: Book detail object
 *       404:
 *         description: Book not found
 */
router.get('/:id', (req, res, next) => {
  try {
    const book = BooksDao.getById(req.params.id);
    if (!book) {
      return res.status(404).json({ success: false, error: 'Book not found' });
    }
    res.json({ success: true, data: book });
  } catch (err) {
    next(err);
  }
});

/**
 * @openapi
 * /api/books/{id}/reviews:
 *   get:
 *     summary: Get paginated community reviews for a book
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *       - in: query
 *         name: page
 *         schema: { type: integer, default: 1 }
 *       - in: query
 *         name: limit
 *         schema: { type: integer, default: 10, maximum: 100 }
 *     responses:
 *       200:
 *         description: Paginated review list
 */
router.get('/:id/reviews', (req, res, next) => {
  try {
    const { page, limit } = req.query;
    const result = ReviewsDao.getByBookId(req.params.id, page, limit);
    res.json({ success: true, count: result.total, ...result });
  } catch (err) {
    next(err);
  }
});

export default router;
