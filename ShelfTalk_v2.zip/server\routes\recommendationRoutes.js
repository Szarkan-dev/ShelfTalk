import { Router } from 'express';
import { BooksDao } from '../db/database.js';

const router = Router();

// ---------------------------------------------------------------------------
// Cosine Vector Affinity Engine
// ---------------------------------------------------------------------------
// Each book and each user query is encoded as a numeric feature vector across
// four independent dimensions.  The cosine similarity of those two vectors
// gives a score in [0, 1] that is entirely independent of vector magnitude,
// so a book with many features is not unfairly boosted over a niche one.
//
//  Dimensions:
//   [0] genreMatch     — binary: 1 if the book carries the requested genre
//   [1] pacingMatch    — binary: 1 if the book's page-count tier matches the
//                        requested pacing (brisk ≤ 350 pp, epic ≥ 500 pp,
//                        reflective = fiction, actionable = non-fiction)
//   [2] qualityScore   — normalised average rating (averageRating / 5)
//   [3] popularityScore— normalised review count capped at 50 reviews
// ---------------------------------------------------------------------------

const GENRE_ALIASES = {
  fiction:     ['Fiction'],
  scifi:       ['Sci-Fi', 'Science Fiction'],
  nonfiction:  ['Non-Fiction'],
  biography:   ['Biography'],
};

/** Resolve user-supplied genre string to canonical genre labels */
function resolveGenres(genre) {
  if (!genre) return [];
  const key = genre.toLowerCase().replace(/[^a-z]/g, '');
  return GENRE_ALIASES[key] || [genre];
}

/** Encode a book into a 4-dimension feature vector */
function encodeBook(book, queryGenres, pacing) {
  // Dimension 0: genre match
  const genreMatch = queryGenres.length > 0 && queryGenres.some(g => book.genres.includes(g)) ? 1 : 0;

  // Dimension 1: pacing match
  let pacingMatch = 0;
  if (pacing === 'brisk'      && book.pageCount <= 350)              pacingMatch = 1;
  if (pacing === 'epic'       && book.pageCount >= 500)              pacingMatch = 1;
  if (pacing === 'reflective' && book.genres.includes('Fiction'))    pacingMatch = 1;
  if (pacing === 'actionable' && book.genres.includes('Non-Fiction')) pacingMatch = 1;

  // Dimension 2: quality (normalised)
  const qualityScore = (book.averageRating || 0) / 5;

  // Dimension 3: popularity (normalised, capped at 50)
  const popularityScore = Math.min(book.totalReviews || 0, 50) / 50;

  return [genreMatch, pacingMatch, qualityScore, popularityScore];
}

/** Encode the user query as the same 4-dimension vector */
function encodeQuery(queryGenres, pacing) {
  const genreMatch     = queryGenres.length > 0 ? 1 : 0;
  const pacingMatch    = pacing ? 1 : 0;
  // We weight quality and popularity equally in the query direction
  const qualityScore   = 1;
  const popularityScore = 1;
  return [genreMatch, pacingMatch, qualityScore, popularityScore];
}

/** Cosine similarity of two equal-length numeric vectors */
function cosineSimilarity(a, b) {
  const dot  = a.reduce((s, v, i) => s + v * b[i], 0);
  const magA = Math.sqrt(a.reduce((s, v) => s + v * v, 0));
  const magB = Math.sqrt(b.reduce((s, v) => s + v * v, 0));
  if (magA === 0 || magB === 0) return 0;
  return dot / (magA * magB);
}

/** Human-readable explanation of why a book matched */
function buildMatchReason(book, queryGenres, pacing, similarity) {
  const parts = [];
  if (queryGenres.length > 0 && queryGenres.some(g => book.genres.includes(g))) {
    parts.push(`matches your ${queryGenres[0]} preference`);
  }
  if (pacing) parts.push(`suits ${pacing} pacing`);
  if (book.averageRating >= 4.5) parts.push(`community favourite at ${book.averageRating}★`);
  const pct = Math.round(similarity * 100);
  return parts.length > 0
    ? `${pct}% affinity — ${parts.join(', ')}.`
    : `${pct}% affinity based on quality and popularity signals.`;
}

// ---------------------------------------------------------------------------

/**
 * @openapi
 * /api/recommendations/match:
 *   post:
 *     summary: Recommend books using cosine vector affinity
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               genre:  { type: string, example: Fiction }
 *               pacing: { type: string, enum: [brisk, epic, reflective, actionable] }
 *               theme:  { type: string, description: Optional extra hint }
 *     responses:
 *       200:
 *         description: Top match and three alternates with affinity percentages
 */
router.post('/match', (req, res, next) => {
  try {
    const { genre, pacing } = req.body;
    const queryGenres = resolveGenres(genre);
    const queryVec    = encodeQuery(queryGenres, pacing);

    const { data: allBooks } = BooksDao.getAll(undefined, undefined, 1, 100);

    const scored = allBooks.map((book) => {
      const bookVec    = encodeBook(book, queryGenres, pacing);
      const similarity = cosineSimilarity(queryVec, bookVec);

      // Map [0,1] cosine score to a [60, 99] display percentage for readability
      const affinityPercentage = Math.round(60 + similarity * 39);

      return {
        book,
        affinityPercentage,
        matchReason: buildMatchReason(book, queryGenres, pacing, similarity),
        _score: similarity
      };
    });

    scored.sort((a, b) => b._score - a._score);

    // Strip internal score field from response
    const clean = scored.map(({ _score, ...rest }) => rest);

    res.json({
      success: true,
      algorithm: 'cosine-vector-affinity-v2',
      topMatch:  clean[0],
      alternates: clean.slice(1, 4)
    });
  } catch (err) {
    next(err);
  }
});

export default router;
